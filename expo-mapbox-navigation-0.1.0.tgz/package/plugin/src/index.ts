import { ConfigPlugin, withGradleProperties } from "expo/config-plugins";

const withAndroidMapbox: ConfigPlugin<{secretKey: string}> = (config, { secretKey }) => {
  return withGradleProperties(config, async (config) => {
    // config = { modResults, modRequest, ...expoConfig }

    const gradle = config.modResults;
    gradle.push({
      type: "property",
      key: "MAPBOX_DOWNLOADS_TOKEN",
      value: secretKey,
    });

    return config;
  });
};

// 💡 Usage:

export default withAndroidMapbox;
