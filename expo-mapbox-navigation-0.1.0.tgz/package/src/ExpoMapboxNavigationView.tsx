import { requireNativeViewManager } from 'expo-modules-core';
import * as React from 'react';
import * as Location from "expo-location";
import {
  ActivityIndicator,
  Platform,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { NavigationViewProps } from './ExpoMapboxNavigation.types';

const NativeView: React.ComponentType<NavigationViewProps> =
  requireNativeViewManager('ExpoMapboxNavigation');

export default function ExpoMapboxNavigationView(props: NavigationViewProps) {
  const [loading, setIsLoading] = React.useState(true);
  const [location, setLocation] = React.useState<
    Location.LocationObject | undefined
  >();

  const checkLocation = () => {
    if (location) {
      return;
    }
    Location.requestForegroundPermissionsAsync()
      .then((status) => {
        if (!status.granted) {
          console.log("not granted");
          return;
        }
        Location.getCurrentPositionAsync({})
          .then((location_) => {
            console.log(location_);
            setLocation(location_);
          })
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e))
      .finally(() => {
        setIsLoading(false);
      });
  };

  React.useEffect(() => {
    const interval = setInterval(checkLocation, 5000);
    return () => clearInterval(interval);
  }, [location]);

  if (loading) {
    return <ActivityIndicator />;
  }
  if (!location) {
    return <Text>No location access</Text>;
  }
  if (Platform.OS !== "android") {
    return <Text>Only supported on Android</Text>;
  }
  return <NativeView {...props} />;
}
